
<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');

error_reporting(E_ERROR | E_WARNING);

$ini_array = parse_ini_file("siruba-php.ini");
$data = json_decode(file_get_contents("php://input"), true);
$username = array($ini_array['username'],'@iransiruba.com');
$password = array($ini_array['year'],$ini_array['type'],$ini_array['jyear']);
$content = array($data['name'],'\r\n',$data["content"]);
$subject = array("Form submit from: ", $data['from']);

function isValidEmail($email)
{
  return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}


include "PHPMailer/class.phpmailer.php";
$mail = new PHPMailer(true);
$mail->IsSMTP();

if (!isset($data["name"])) {
  $data = array("success" => false, "code" => "name", "message" => 'لطفا نام خود را وارد کنید');
  echo json_encode($data);
  exit();
}

if (strlen($data["name"]) < 6) {
  $data = array("success" => false, "code" => "name", "message" => 'لطفا نام خود را کامل وارد کنید');
  echo json_encode($data);
  exit();
}

if (!isset($data["from"])) {
  $data = array("success" => false, "code" => "from", "message" => 'ایمیل را وارد کنید');
  echo json_encode($data);
  exit();
}

if (!strlen($data["from"])) {
  $data = array("success" => false, "code" => "from", "message" => 'ایمیل را وارد کنید');
  echo json_encode($data);
  exit();
}

if (!isValidEmail($data["from"])) {
  $data = array("success" => false, "code" => "from", "message" => 'فرمت ایمیل اشتباه است');
  echo json_encode($data);
  exit();
}

if (!isset($data["content"])) {
  $data = array("success" => false, "code" => "content", "message" => 'متن تماس را وارد کنید');
  echo json_encode($data);
  exit();
}


if (strlen($data["content"]) < 6) {
  $data = array("success" => false, "code" => "content", "message" => 'متن تماس را کامل کنید');
  echo json_encode($data);
  exit();
}

try {
  $mail->Host = $ini_array['server'];
  $mail->SMTPAuth = false;
  $mail->Port = 25;
  $mail->Username = join('',$username);
  $mail->Password = join('',$password);
  $mail->AddAddress(join('',$username));
  $mail->SetFrom($data["from"], "");
  $mail->Subject = join('',$subject);
  $mail->CharSet = "UTF-8";
  $mail->ContentType = "text/htm";
  $mail->MsgHTML(join('',$content));
  $mail->Send();
  $data = array("success" => true);
  echo json_encode($data);
} 
catch (phpmailerException $e) 
{
  $data = array("success" => false, "code" => "server", "message" => 'اشکال در ارسال پیام. ارسال مجدد. (1)');
  echo json_encode($data);
  exit();
} 
catch (Exception $e) 
{
  $data = array("success" => false, "code" => "server", "message" => 'اشکال در ارسال پیام. ارسال مجدد. (2)');
  echo json_encode($data);
  exit();
}
exit();
?>
