import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  output: "export",
  images: { unoptimized: true },
  allowedDevOrigins: ["192.168.1.*"],
};

export default nextConfig;
